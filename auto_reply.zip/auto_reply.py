import os
import re
import time
import re , requests
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/youtube.force-ssl']
OPENAI_API_KEY = "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"

def extract_uid(text):
    """
    Extracts first UID (6+ digit number) from a text command
    Examples:
    'get 776702343'
    '/get 776702343'
    'profile uid=776702343'
    """
    match = re.search(r"\d{6,}", text)
    return match.group() if match else None


# ---------------------------
# 2. Fetch player info from API
# ---------------------------
def get_player_info(uid, server="IND"):

    try:
        url = f"http://127.0.0.1:5002/info?uid={uid}&server_name={server}"

        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        basic = data.get("basicInfo", {})

        return {
            "UID": basic.get("accountId", "N/A"),
            "Name (Nickname)": basic.get("nickname", "N/A"),
            "Region / Server": basic.get("region", server),
            "Level": basic.get("level", 0),
            "Likes": basic.get("liked", 0)
        }
    except (ValueError, KeyError) as e:
        print(f"Error parsing player info: {e}")
        return None




def get_video_id(url):
    pattern = r"(?:v=|\/)([0-9A-Za-z_-]{11}).*"
    match = re.search(pattern, url)
    if match:
        return match.group(1)
    return None

def authenticate_youtube():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('client_secret.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token:
            token.write(creds.to_json())
    return build('youtube', 'v3', credentials=creds)

def get_live_chat_id(youtube, video_id):
    request = youtube.videos().list(
        part='liveStreamingDetails',
        id=video_id
    )
    response = request.execute()
    live_chat_id = response['items'][0]['liveStreamingDetails'].get('activeLiveChatId')
    return live_chat_id



def post_reply(youtube, live_chat_id, reply_message):
    youtube.liveChatMessages().insert(
        part='snippet',
        body={
            'snippet': {
                'liveChatId': live_chat_id,
                'type': 'textMessageEvent',
                'textMessageDetails': {
                    'messageText': reply_message
                }
            }
        }
    ).execute()

def read_live_chat(youtube, live_chat_id):
    next_page_token = None
    while True:
        # Fetch live chat messages
        request = youtube.liveChatMessages().list(
            liveChatId=live_chat_id,
            part='snippet,authorDetails',
            pageToken=next_page_token
        )
        response = request.execute()
        # Display each chat message
        for item in response['items']:
            author = item['authorDetails']['displayName']
            message = item['snippet']['displayMessage']
            print(f"{author}: {message}")
            if 'get' not in message.lower():
                continue
            uid = extract_uid(''.join(message.split()))
            if not uid:
                print( "❌ No UID found in command")
                continue 
            
            print(f"✅ Extracted UID: {uid}")
            info = get_player_info(uid) 
            if not info:
                print("❌ Failed to retrieve player info")
                continue 

            #Uncomment below to reply to each message with the reply_message
            youtube.liveChatMessages().insert(
                part='snippet',
                body={
                    'snippet': {
                        'liveChatId': live_chat_id,
                        'type': 'textMessageEvent',
                        'textMessageDetails': {
                            'messageText': "Hello " + info["Name (Nickname)"] + "! Your Level is " + str(info["Level"]) + " and Likes: " + str(info["Likes"])
                        }
                    }
                }
            ).execute()

        # Update the nextPageToken to get new messages only
        next_page_token = response.get('nextPageToken')
        
        # Pause before fetching the next set of messages to avoid rate limits
        time.sleep(5)
    # next_page_token = None
    # while True:
    #     request = youtube.liveChatMessages().list(
    #     liveChatId=live_chat_id,
    #     part='snippet,authorDetails',
    #     pageToken=next_page_token
    #     )
    #     response = request.execute()
    #     for item in response['items']:
    #         author = item['authorDetails']['displayName']
    #         message = item['snippet']['displayMessage']
    #         print(f"{author}: {message}")
    #         uid = extract_uid(message)
    #         if not uid:
    #             print( "❌ No UID found in command")

    #         info = get_player_info(uid)
    #         reply_message = info
    #         print(f"Generated reply: {reply_message}")
    #         post_reply(youtube, live_chat_id, reply_message)

    #     next_page_token = response.get('nextPageToken')
    #     time.sleep(5)

def main():
    youtube = authenticate_youtube()
    url = "https://www.youtube.com/live/35zdy8Alr5c?si=_ONfWPwe_XkC_EJv"  # Replace with the actual video URL
    video_id = get_video_id(url)
    live_chat_id = get_live_chat_id(youtube, video_id)
    if live_chat_id:
        read_live_chat(youtube, live_chat_id)
    else:
        print("Live chat is not available for this video.")

if __name__ == '__main__':
    main()
